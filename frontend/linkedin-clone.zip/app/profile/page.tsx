import Link from "next/link"

export default function ProfilePage() {
  return (
    <div className="min-h-screen bg-gray-100">
      <header className="sticky top-0 z-10 bg-white border-b">
        <div className="container flex items-center justify-between h-14 px-4 mx-auto">
          <div className="flex items-center gap-4">
            <Link href="/" className="text-2xl font-bold text-blue-600">
              in
            </Link>
            <div className="relative hidden md:block">
              <svg
                className="absolute left-2 top-2.5 h-4 w-4 text-gray-500"
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <circle cx="11" cy="11" r="8" />
                <path d="m21 21-4.3-4.3" />
              </svg>
              <input placeholder="Search" className="w-64 pl-8 bg-gray-100 border-none rounded-md h-9 px-3" />
            </div>
          </div>
          <nav className="flex items-center space-x-1">
            <Link href="/" className="flex flex-col items-center px-1 py-1">
              <div className="flex items-center justify-center h-9 w-9 rounded-md text-gray-500">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
                  <polyline points="9 22 9 12 15 12 15 22" />
                </svg>
              </div>
              <span className="text-xs mt-0.5 text-gray-500">Home</span>
            </Link>

            <Link href="/network" className="flex flex-col items-center px-1 py-1">
              <div className="flex items-center justify-center h-9 w-9 rounded-md text-gray-500">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                  <circle cx="9" cy="7" r="4" />
                  <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                  <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                </svg>
              </div>
              <span className="text-xs mt-0.5 text-gray-500">My Network</span>
            </Link>

            <Link href="#" className="flex flex-col items-center px-1 py-1">
              <div className="flex items-center justify-center h-9 w-9 rounded-md text-gray-500">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <rect width="20" height="14" x="2" y="7" rx="2" ry="2" />
                  <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" />
                </svg>
              </div>
              <span className="text-xs mt-0.5 text-gray-500">Jobs</span>
            </Link>

            <Link href="#" className="flex flex-col items-center px-1 py-1">
              <div className="flex items-center justify-center h-9 w-9 rounded-md text-gray-500">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
                </svg>
              </div>
              <span className="text-xs mt-0.5 text-gray-500">Messaging</span>
            </Link>

            <Link href="#" className="flex flex-col items-center px-1 py-1">
              <div className="flex items-center justify-center h-9 w-9 rounded-md text-gray-500">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
                  <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" />
                </svg>
              </div>
              <span className="text-xs mt-0.5 text-gray-500">Notifications</span>
            </Link>

            <Link href="/profile" className="flex flex-col items-center">
              <div className="h-7 w-7 rounded-full overflow-hidden">
                <img src="/placeholder.svg?height=32&width=32" alt="User" className="h-full w-full object-cover" />
              </div>
              <span className="text-xs mt-0.5 text-black">Me ▼</span>
            </Link>
          </nav>
        </div>
      </header>

      <main className="container px-4 py-6 mx-auto">
        {/* Profile Header */}
        <div className="bg-white rounded-lg shadow mb-6">
          <div className="h-48 bg-gradient-to-r from-blue-500 to-blue-700 rounded-t-lg relative">
            <button className="absolute top-4 right-4 bg-white/20 hover:bg-white/30 text-white rounded-full p-2">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z" />
              </svg>
            </button>
          </div>
          <div className="relative pb-6 px-6">
            <div className="absolute -top-16 left-8">
              <div className="h-32 w-32 rounded-full border-4 border-white overflow-hidden">
                <img
                  src="/placeholder.svg?height=128&width=128"
                  alt="John Doe"
                  className="h-full w-full object-cover"
                />
              </div>
            </div>
            <div className="pt-20">
              <div className="flex justify-between">
                <div>
                  <h1 className="text-2xl font-bold">John Doe</h1>
                  <p className="text-lg">Software Developer at Tech Company</p>
                  <p className="text-sm text-gray-500 mt-1">San Francisco Bay Area • 500+ connections</p>
                  <div className="flex gap-2 mt-3">
                    <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-1 rounded">Open to</button>
                    <button className="border border-gray-300 px-4 py-1 rounded hover:bg-gray-50">
                      Add profile section
                    </button>
                    <button className="border border-gray-300 px-4 py-1 rounded hover:bg-gray-50">More</button>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="w-64 bg-white rounded-lg shadow border">
                    <div className="p-3">
                      <div className="flex items-center gap-2">
                        <img src="/placeholder.svg?height=40&width=40" alt="Tech Company" className="w-10 h-10" />
                        <div>
                          <h4 className="font-medium text-sm">Tech Company</h4>
                          <p className="text-xs text-gray-500">Software Company</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="w-64 bg-white rounded-lg shadow border">
                    <div className="p-3">
                      <div className="flex items-center gap-2">
                        <img src="/placeholder.svg?height=40&width=40" alt="University" className="w-10 h-10" />
                        <div>
                          <h4 className="font-medium text-sm">University of Technology</h4>
                          <p className="text-xs text-gray-500">Educational Institution</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-6">
            {/* About Section */}
            <div className="bg-white rounded-lg shadow">
              <div className="flex flex-row items-center justify-between p-4">
                <h3 className="text-lg font-medium">About</h3>
                <button className="p-2 rounded-full hover:bg-gray-100">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z" />
                  </svg>
                </button>
              </div>
              <div className="px-4 pb-4">
                <p>
                  Passionate software developer with 5+ years of experience in full-stack development. Specialized in
                  React, Node.js, and cloud technologies. Committed to creating efficient, scalable, and user-friendly
                  applications that solve real-world problems.
                </p>
              </div>
            </div>

            {/* Experience Section */}
            <div className="bg-white rounded-lg shadow">
              <div className="flex flex-row items-center justify-between p-4">
                <h3 className="text-lg font-medium">Experience</h3>
                <div className="flex gap-2">
                  <button className="p-2 rounded-full hover:bg-gray-100">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M12 5v14M5 12h14" />
                    </svg>
                  </button>
                  <button className="p-2 rounded-full hover:bg-gray-100">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z" />
                    </svg>
                  </button>
                </div>
              </div>
              <div className="px-4 pb-4 space-y-6">
                <div className="flex gap-4">
                  <img src="/placeholder.svg?height=56&width=56" alt="Tech Company" className="w-14 h-14" />
                  <div>
                    <h3 className="font-semibold">Senior Software Developer</h3>
                    <p className="text-sm">Tech Company · Full-time</p>
                    <p className="text-sm text-gray-500">Jan 2021 - Present · 2 yrs 3 mos</p>
                    <p className="text-sm text-gray-500">San Francisco, California</p>
                    <p className="mt-2">
                      Leading development of the company's flagship product. Managing a team of 5 developers and
                      implementing best practices for code quality and performance.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <img src="/placeholder.svg?height=56&width=56" alt="Previous Company" className="w-14 h-14" />
                  <div>
                    <h3 className="font-semibold">Software Developer</h3>
                    <p className="text-sm">Previous Company · Full-time</p>
                    <p className="text-sm text-gray-500">Jun 2018 - Dec 2020 · 2 yrs 7 mos</p>
                    <p className="text-sm text-gray-500">San Francisco, California</p>
                    <p className="mt-2">
                      Developed and maintained web applications using React and Node.js. Collaborated with design and
                      product teams to implement new features.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Education Section */}
            <div className="bg-white rounded-lg shadow">
              <div className="flex flex-row items-center justify-between p-4">
                <h3 className="text-lg font-medium">Education</h3>
                <div className="flex gap-2">
                  <button className="p-2 rounded-full hover:bg-gray-100">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M12 5v14M5 12h14" />
                    </svg>
                  </button>
                  <button className="p-2 rounded-full hover:bg-gray-100">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z" />
                    </svg>
                  </button>
                </div>
              </div>
              <div className="px-4 pb-4 space-y-6">
                <div className="flex gap-4">
                  <img src="/placeholder.svg?height=56&width=56" alt="University" className="w-14 h-14" />
                  <div>
                    <h3 className="font-semibold">University of Technology</h3>
                    <p className="text-sm">Bachelor of Science in Computer Science</p>
                    <p className="text-sm text-gray-500">2014 - 2018</p>
                    <p className="mt-2">
                      Graduated with honors. Specialized in software engineering and artificial intelligence.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Skills Section */}
            <div className="bg-white rounded-lg shadow">
              <div className="flex flex-row items-center justify-between p-4">
                <h3 className="text-lg font-medium">Skills</h3>
                <div className="flex gap-2">
                  <button className="p-2 rounded-full hover:bg-gray-100">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M12 5v14M5 12h14" />
                    </svg>
                  </button>
                  <button className="p-2 rounded-full hover:bg-gray-100">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z" />
                    </svg>
                  </button>
                </div>
              </div>
              <div className="px-4 pb-4">
                <div className="space-y-4">
                  <div>
                    <h3 className="font-semibold">JavaScript</h3>
                    <p className="text-sm text-gray-500">7 endorsements</p>
                  </div>
                  <div>
                    <h3 className="font-semibold">React.js</h3>
                    <p className="text-sm text-gray-500">12 endorsements</p>
                  </div>
                  <div>
                    <h3 className="font-semibold">Node.js</h3>
                    <p className="text-sm text-gray-500">9 endorsements</p>
                  </div>
                  <div>
                    <h3 className="font-semibold">TypeScript</h3>
                    <p className="text-sm text-gray-500">5 endorsements</p>
                  </div>
                  <div>
                    <h3 className="font-semibold">AWS</h3>
                    <p className="text-sm text-gray-500">3 endorsements</p>
                  </div>
                </div>
                <button className="w-full border border-gray-300 rounded py-2 px-3 mt-4 hover:bg-gray-50">
                  Show all 15 skills
                </button>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            {/* Profile Strength */}
            <div className="bg-white rounded-lg shadow">
              <div className="p-4">
                <h3 className="text-base font-medium mb-4">Profile Strength</h3>
                <div className="space-y-4">
                  <div className="h-2 w-full bg-gray-200 rounded-full overflow-hidden">
                    <div className="h-full bg-blue-600 w-4/5"></div>
                  </div>
                  <p className="text-sm">
                    Your profile is <strong>intermediate</strong>
                  </p>
                  <div className="bg-blue-50 p-3 rounded-lg">
                    <p className="text-sm font-medium">Suggested for you</p>
                    <p className="text-sm text-gray-500 mt-1">Add your certifications to stand out</p>
                    <button className="text-blue-600 p-0 h-auto mt-1 text-sm bg-transparent">Add certification</button>
                  </div>
                </div>
              </div>
            </div>

            {/* People Also Viewed */}
            <div className="bg-white rounded-lg shadow">
              <div className="p-4">
                <h3 className="text-base font-medium mb-4">People also viewed</h3>
                <div className="space-y-4">
                  {[
                    {
                      name: "Jane Smith",
                      title: "UX Designer at Design Co",
                      img: "/placeholder.svg?height=48&width=48",
                    },
                    {
                      name: "Mike Johnson",
                      title: "Full Stack Developer at Tech Startup",
                      img: "/placeholder.svg?height=48&width=48",
                    },
                    {
                      name: "Sarah Williams",
                      title: "Product Manager at Innovation Inc",
                      img: "/placeholder.svg?height=48&width=48",
                    },
                  ].map((person, i) => (
                    <div key={i} className="flex items-start gap-3">
                      <div className="h-10 w-10 rounded-full overflow-hidden">
                        <img
                          src={person.img || "/placeholder.svg"}
                          alt={person.name}
                          className="h-full w-full object-cover"
                        />
                      </div>
                      <div>
                        <h4 className="font-medium text-sm">{person.name}</h4>
                        <p className="text-xs text-gray-500">{person.title}</p>
                        <button className="mt-2 h-8 border border-gray-300 rounded px-3 py-1 text-sm hover:bg-gray-50">
                          Connect
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Learning Section */}
            <div className="bg-white rounded-lg shadow">
              <div className="p-4">
                <h3 className="text-base font-medium mb-2">Learning</h3>
                <p className="text-sm">Add new skills with these courses, free for 24 hours</p>
                <div className="mt-3 space-y-3">
                  <div className="bg-gray-100 p-3 rounded-lg">
                    <h4 className="font-medium text-sm">Advanced React Patterns</h4>
                    <p className="text-xs text-gray-500 mt-1">24,567 viewers</p>
                  </div>
                  <div className="bg-gray-100 p-3 rounded-lg">
                    <h4 className="font-medium text-sm">TypeScript for React Developers</h4>
                    <p className="text-xs text-gray-500 mt-1">12,345 viewers</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

