"use client"

import Link from "next/link"
import { useEffect } from "react"
import { useRouter } from "next/navigation"
import LogoutButton from "@/components/logout-button"

export default function HomePage() {
  const router = useRouter()

  // Verificar se o usuário está autenticado
  // Isso é redundante com o middleware, mas serve como fallback
  useEffect(() => {
    const token = document.cookie.includes("auth_token")
    if (!token) {
      router.push("/login")
    }
  }, [router])

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="sticky top-0 z-10 bg-white border-b">
        <div className="container flex items-center justify-between h-14 px-4 mx-auto">
          <div className="flex items-center gap-4">
            <Link href="/" className="text-2xl font-bold text-blue-600">
              in
            </Link>
            <div className="relative hidden md:block">
              <svg
                className="absolute left-2 top-2.5 h-4 w-4 text-gray-500"
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <circle cx="11" cy="11" r="8" />
                <path d="m21 21-4.3-4.3" />
              </svg>
              <input placeholder="Search" className="w-64 pl-8 bg-gray-100 border-none rounded-md h-9 px-3" />
            </div>
          </div>
          <nav className="flex items-center space-x-1">
            <Link href="/" className="flex flex-col items-center px-1 py-1">
              <div className="flex items-center justify-center h-9 w-9 rounded-md text-black">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
                  <polyline points="9 22 9 12 15 12 15 22" />
                </svg>
              </div>
              <span className="text-xs mt-0.5 text-black">Home</span>
            </Link>

            <Link href="/network" className="flex flex-col items-center px-1 py-1">
              <div className="flex items-center justify-center h-9 w-9 rounded-md text-gray-500">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                  <circle cx="9" cy="7" r="4" />
                  <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                  <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                </svg>
              </div>
              <span className="text-xs mt-0.5 text-gray-500">My Network</span>
            </Link>

            <Link href="#" className="flex flex-col items-center px-1 py-1">
              <div className="flex items-center justify-center h-9 w-9 rounded-md text-gray-500">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <rect width="20" height="14" x="2" y="7" rx="2" ry="2" />
                  <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" />
                </svg>
              </div>
              <span className="text-xs mt-0.5 text-gray-500">Jobs</span>
            </Link>

            <Link href="#" className="flex flex-col items-center px-1 py-1">
              <div className="flex items-center justify-center h-9 w-9 rounded-md text-gray-500">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
                </svg>
              </div>
              <span className="text-xs mt-0.5 text-gray-500">Messaging</span>
            </Link>

            <Link href="#" className="flex flex-col items-center px-1 py-1">
              <div className="flex items-center justify-center h-9 w-9 rounded-md text-gray-500">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
                  <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" />
                </svg>
              </div>
              <span className="text-xs mt-0.5 text-gray-500">Notifications</span>
            </Link>

            <div className="relative group">
              <Link href="/profile" className="flex flex-col items-center">
                <div className="h-7 w-7 rounded-full overflow-hidden">
                  <img src="/placeholder.svg?height=32&width=32" alt="User" className="h-full w-full object-cover" />
                </div>
                <span className="text-xs mt-0.5">Me ▼</span>
              </Link>

              <div className="absolute right-0 mt-1 w-48 bg-white rounded-md shadow-lg py-1 hidden group-hover:block">
                <Link href="/profile" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                  View Profile
                </Link>
                <Link href="/settings" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                  Settings
                </Link>
                <div className="border-t border-gray-100 my-1"></div>
                <div className="px-4 py-2">
                  <LogoutButton />
                </div>
              </div>
            </div>
          </nav>
        </div>
      </header>

      {/* Resto do conteúdo da página inicial permanece o mesmo */}
      {/* Conteúdo principal */}
      <main className="container px-4 py-6 mx-auto">
        <div className="grid grid-cols-1 gap-6 md:grid-cols-4">
          {/* Profile Card */}
          <div className="md:col-span-1 h-fit bg-white rounded-lg shadow">
            <div className="p-0">
              <div className="h-16 bg-blue-600 rounded-t-lg"></div>
              <div className="flex justify-center -mt-8">
                <div className="h-16 w-16 rounded-full border-4 border-white overflow-hidden">
                  <img src="/placeholder.svg?height=64&width=64" alt="User" className="h-full w-full object-cover" />
                </div>
              </div>
            </div>
            <div className="text-center pt-2 p-4">
              <h3 className="font-semibold text-lg">John Doe</h3>
              <p className="text-sm text-gray-500">Software Developer at Tech Company</p>
              <div className="border-t border-b my-3 py-3">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Profile views</span>
                  <span className="font-semibold text-blue-600">142</span>
                </div>
                <div className="flex justify-between text-sm mt-2">
                  <span className="text-gray-500">Connection</span>
                  <span className="font-semibold text-blue-600">467</span>
                </div>
              </div>
              <p className="text-sm text-gray-500 text-left">Access exclusive tools & insights</p>
              <div className="flex items-center gap-2 mt-2">
                <div className="w-4 h-4 bg-yellow-600"></div>
                <span className="text-sm font-medium">Try Premium for free</span>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="md:col-span-2 space-y-4">
            {/* Post Creator */}
            <div className="bg-white p-4 rounded-lg shadow">
              <div className="flex gap-3">
                <div className="h-10 w-10 rounded-full overflow-hidden">
                  <img src="/placeholder.svg?height=40&width=40" alt="User" className="h-full w-full object-cover" />
                </div>
                <button className="w-full justify-start text-gray-500 rounded-full border border-gray-300 px-4 py-2 text-left hover:bg-gray-50">
                  Start a post
                </button>
              </div>
              <div className="flex justify-between mt-3">
                <button className="flex items-center text-gray-500 px-3 py-1 rounded hover:bg-gray-100">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-5 w-5 mr-2 text-blue-500"
                  >
                    <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
                    <circle cx="9" cy="9" r="2" />
                    <path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21" />
                  </svg>
                  Photo
                </button>
                <button className="flex items-center text-gray-500 px-3 py-1 rounded hover:bg-gray-100">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-5 w-5 mr-2 text-green-500"
                  >
                    <path d="M22 8a6 6 0 0 1-5.3 5.96l-.4.04H9.6a6.97 6.97 0 0 0-5.2 2.27l-.4.4.53-.53A7 7 0 0 1 9.6 14h6.7a8 8 0 0 0 0-16h-6.3a6 6 0 0 0 0 12h3" />
                  </svg>
                  Video
                </button>
                <button className="flex items-center text-gray-500 px-3 py-1 rounded hover:bg-gray-100">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-5 w-5 mr-2 text-orange-500"
                  >
                    <rect width="18" height="18" x="3" y="3" rx="2" />
                    <path d="M3 9h18" />
                    <path d="M9 21V9" />
                  </svg>
                  Event
                </button>
                <button className="flex items-center text-gray-500 px-3 py-1 rounded hover:bg-gray-100">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-5 w-5 mr-2 text-red-500"
                  >
                    <path d="M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-2 2Zm0 0a2 2 0 0 1-2-2v-9c0-1.1.9-2 2-2h2" />
                  </svg>
                  Article
                </button>
              </div>
            </div>

            {/* Posts */}
            <div className="bg-white rounded-lg shadow">
              <div className="p-4 pb-0">
                <div className="flex justify-between">
                  <div className="flex gap-3">
                    <div className="h-10 w-10 rounded-full overflow-hidden">
                      <img
                        src="/placeholder.svg?height=40&width=40"
                        alt="Sarah Lee"
                        className="h-full w-full object-cover"
                      />
                    </div>
                    <div>
                      <h3 className="text-base font-medium">Sarah Lee</h3>
                      <p className="text-sm text-gray-500">Product Manager at Innovation Inc.</p>
                      <p className="text-sm text-gray-500">2d • 🌎</p>
                    </div>
                  </div>
                  <button className="rounded-full p-2 hover:bg-gray-100">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-5 w-5"
                    >
                      <circle cx="12" cy="12" r="1" />
                      <circle cx="19" cy="12" r="1" />
                      <circle cx="5" cy="12" r="1" />
                    </svg>
                  </button>
                </div>
              </div>
              <div className="p-4">
                <p>
                  Excited to announce that we've just launched our new product! It's been months of hard work, but the
                  team pulled through. Check it out and let me know what you think! #ProductLaunch #Innovation
                </p>
                <div className="mt-3 rounded-lg overflow-hidden">
                  <img src="/placeholder.svg?height=300&width=600" alt="Product launch" className="w-full h-auto" />
                </div>
              </div>
              <div className="border-t">
                <div className="flex w-full">
                  <button className="flex-1 flex items-center justify-center py-3 hover:bg-gray-100">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-5 w-5 mr-2"
                    >
                      <path d="M7 10v12" />
                      <path d="M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2h0a3.13 3.13 0 0 1 3 3.88Z" />
                    </svg>
                    Like
                  </button>
                  <button className="flex-1 flex items-center justify-center py-3 hover:bg-gray-100">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-5 w-5 mr-2"
                    >
                      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
                    </svg>
                    Comment
                  </button>
                  <button className="flex-1 flex items-center justify-center py-3 hover:bg-gray-100">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-5 w-5 mr-2"
                    >
                      <path d="m3 3 5 5" />
                      <path d="m3 3 5-5" />
                      <path d="M3 13v-2a2 2 0 0 1 2-2h3.9a2 2 0 0 0 1.69-.9l.81-1.2a2 2 0 0 1 1.67-.9h2.86a2 2 0 0 1 1.67.9l.81 1.2a2 2 0 0 0 1.69.9H21a2 2 0 0 1 2 2v2" />
                      <path d="M3 18a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-5" />
                      <path d="m16 9-3 3" />
                      <path d="m16 9 3 3" />
                    </svg>
                    Repost
                  </button>
                  <button className="flex-1 flex items-center justify-center py-3 hover:bg-gray-100">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-5 w-5 mr-2"
                    >
                      <path d="M22 2 11 13" />
                      <path d="m22 2-7 20-4-9-9-4 20-7z" />
                    </svg>
                    Send
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* News & Ads */}
          <div className="md:col-span-1 space-y-4">
            <div className="bg-white rounded-lg shadow">
              <div className="p-4">
                <h3 className="text-base font-medium mb-4">LinkedIn News</h3>
                <ul className="space-y-3">
                  {[
                    "Tech layoffs continue in 2023",
                    "Remote work trends shifting",
                    "AI revolution in workplace",
                    "Startup funding hits new high",
                    "Skills gap widens in tech sector",
                  ].map((item, i) => (
                    <li key={i} className="flex gap-2">
                      <span className="text-gray-500">•</span>
                      <span className="font-medium text-sm">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow">
              <div className="p-4">
                <div className="text-right text-xs text-gray-500 mb-2">Ad</div>
                <div className="flex gap-3">
                  <img src="/placeholder.svg?height=60&width=60" alt="Advertisement" className="w-14 h-14 rounded" />
                  <div>
                    <h4 className="font-medium text-sm">Grow your skills with online courses</h4>
                    <p className="text-xs text-gray-500 mt-1">Learn from industry experts at your own pace</p>
                  </div>
                </div>
                <button className="w-full mt-3 border border-gray-300 rounded-md py-1 px-3 text-sm hover:bg-gray-50">
                  Learn More
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

