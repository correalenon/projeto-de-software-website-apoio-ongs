"use client"

import type React from "react"

import Link from "next/link"
import { useState } from "react"
import { useRouter } from "next/navigation"

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const router = useRouter()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Validação básica
    if (!email || !password) {
      setError("Por favor, preencha todos os campos")
      return
    }

    // Simulação de login bem-sucedido
    // Em uma aplicação real, você faria uma chamada à API aqui

    // Definir o cookie de autenticação (em uma aplicação real, isso seria feito pelo servidor)
    document.cookie = `auth_token=dummy_token; path=/; max-age=${60 * 60 * 24 * 7}` // 7 dias

    // Redirecionar para a página inicial
    router.push("/")
  }

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <header className="bg-white py-4 px-4 md:px-8 shadow-sm">
        <div className="container mx-auto">
          <Link href="/" className="text-3xl font-bold text-blue-600">
            in
          </Link>
        </div>
      </header>

      <main className="flex-grow flex items-center justify-center py-12 px-4">
        <div className="max-w-md w-full space-y-8">
          <div className="text-center">
            <h2 className="mt-6 text-3xl font-bold text-gray-900">Sign in to LinkedIn</h2>
            <p className="mt-2 text-sm text-gray-600">Stay updated on your professional world</p>
          </div>

          <div className="bg-white p-8 rounded-lg shadow">
            {error && <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-md text-sm">{error}</div>}

            <form className="space-y-6" onSubmit={handleSubmit}>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                  Email or phone
                </label>
                <div className="mt-1">
                  <input
                    id="email"
                    name="email"
                    type="text"
                    autoComplete="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                  Password
                </label>
                <div className="mt-1">
                  <input
                    id="password"
                    name="password"
                    type="password"
                    autoComplete="current-password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <input
                    id="remember-me"
                    name="remember-me"
                    type="checkbox"
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                  <label htmlFor="remember-me" className="ml-2 block text-sm text-gray-900">
                    Remember me
                  </label>
                </div>

                <div className="text-sm">
                  <a href="#" className="font-medium text-blue-600 hover:text-blue-500">
                    Forgot password?
                  </a>
                </div>
              </div>

              <div>
                <button
                  type="submit"
                  className="w-full flex justify-center py-2 px-4 border border-transparent rounded-full shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  Sign in
                </button>
              </div>
            </form>

            <div className="mt-6">
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-300"></div>
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-2 bg-white text-gray-500">Or sign in with</span>
                </div>
              </div>

              <div className="mt-6 grid grid-cols-2 gap-3">
                <button
                  type="button"
                  className="w-full inline-flex justify-center py-2 px-4 border border-gray-300 rounded-md shadow-sm bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"
                >
                  <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path
                      fillRule="evenodd"
                      d="M12 2C6.477 2 2 6.477 2 12c0 4.42 2.865 8.166 6.839 9.489.5.092.682-.217.682-.482 0-.237-.008-.866-.013-1.7-2.782.603-3.369-1.34-3.369-1.34-.454-1.156-1.11-1.462-1.11-1.462-.908-.62.069-.608.069-.608 1.003.07 1.531 1.03 1.531 1.03.892 1.529 2.341 1.087 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.11-4.555-4.943 0-1.091.39-1.984 1.029-2.683-.103-.253-.446-1.27.098-2.647 0 0 .84-.268 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.114 2.504.336 1.909-1.294 2.747-1.026 2.747-1.026.546 1.377.202 2.394.1 2.647.64.699 1.028 1.592 1.028 2.683 0 3.842-2.339 4.687-4.566 4.935.359.309.678.919.678 1.852 0 1.336-.012 2.415-.012 2.743 0 .267.18.578.688.48C19.138 20.161 22 16.416 22 12c0-5.523-4.477-10-10-10z"
                      clipRule="evenodd"
                    />
                  </svg>
                </button>

                <button
                  type="button"
                  className="w-full inline-flex justify-center py-2 px-4 border border-gray-300 rounded-md shadow-sm bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"
                >
                  <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path
                      fillRule="evenodd"
                      d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1.41 15.06v-1.72c.69.27 1.22.41 1.85.41 1.63 0 3.13-.91 3.13-2.77 0-1.22-.53-2.03-1.31-2.48.52-.19 1.5-.51 1.5-1.35 0-1.24-1.31-1.8-2.27-1.8-.96 0-1.5.49-1.5.49l-.39-.7s.78-.66 2.34-.66c1.85 0 3.47.91 3.47 2.83 0 1.72-1.63 2.41-1.63 2.41s1.39.53 1.39 2.03c0 2.05-2.27 3.31-4.46 3.31-1.34 0-2.12-.41-2.12-.41z"
                      clipRule="evenodd"
                    />
                  </svg>
                </button>
              </div>
            </div>
          </div>

          <div className="text-center mt-4">
            <p className="text-sm text-gray-600">
              New to LinkedIn?{" "}
              <Link href="/signup" className="font-medium text-blue-600 hover:text-blue-500">
                Join now
              </Link>
            </p>
          </div>
        </div>
      </main>

      <footer className="bg-white py-6 px-4">
        <div className="container mx-auto">
          <div className="flex flex-wrap justify-center text-xs text-gray-500 gap-x-4 gap-y-2">
            <Link href="#" className="hover:text-blue-600">
              About
            </Link>
            <Link href="#" className="hover:text-blue-600">
              Accessibility
            </Link>
            <Link href="#" className="hover:text-blue-600">
              User Agreement
            </Link>
            <Link href="#" className="hover:text-blue-600">
              Privacy Policy
            </Link>
            <Link href="#" className="hover:text-blue-600">
              Cookie Policy
            </Link>
            <Link href="#" className="hover:text-blue-600">
              Copyright Policy
            </Link>
            <Link href="#" className="hover:text-blue-600">
              Brand Policy
            </Link>
            <Link href="#" className="hover:text-blue-600">
              Guest Controls
            </Link>
            <Link href="#" className="hover:text-blue-600">
              Community Guidelines
            </Link>
          </div>
          <div className="text-center mt-4 text-xs text-gray-500">
            <p>LinkedIn Corporation © {new Date().getFullYear()}</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

