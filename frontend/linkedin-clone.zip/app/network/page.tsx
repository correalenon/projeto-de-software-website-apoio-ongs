import Link from "next/link"

export default function NetworkPage() {
  return (
    <div className="min-h-screen bg-gray-100">
      <header className="sticky top-0 z-10 bg-white border-b">
        <div className="container flex items-center justify-between h-14 px-4 mx-auto">
          <div className="flex items-center gap-4">
            <Link href="/" className="text-2xl font-bold text-blue-600">
              in
            </Link>
            <div className="relative hidden md:block">
              <svg
                className="absolute left-2 top-2.5 h-4 w-4 text-gray-500"
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <circle cx="11" cy="11" r="8" />
                <path d="m21 21-4.3-4.3" />
              </svg>
              <input placeholder="Search" className="w-64 pl-8 bg-gray-100 border-none rounded-md h-9 px-3" />
            </div>
          </div>
          <nav className="flex items-center space-x-1">
            <Link href="/" className="flex flex-col items-center px-1 py-1">
              <div className="flex items-center justify-center h-9 w-9 rounded-md text-gray-500">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
                  <polyline points="9 22 9 12 15 12 15 22" />
                </svg>
              </div>
              <span className="text-xs mt-0.5 text-gray-500">Home</span>
            </Link>

            <Link href="/network" className="flex flex-col items-center px-1 py-1">
              <div className="flex items-center justify-center h-9 w-9 rounded-md text-black">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                  <circle cx="9" cy="7" r="4" />
                  <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                  <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                </svg>
              </div>
              <span className="text-xs mt-0.5 text-black">My Network</span>
            </Link>

            <Link href="#" className="flex flex-col items-center px-1 py-1">
              <div className="flex items-center justify-center h-9 w-9 rounded-md text-gray-500">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <rect width="20" height="14" x="2" y="7" rx="2" ry="2" />
                  <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" />
                </svg>
              </div>
              <span className="text-xs mt-0.5 text-gray-500">Jobs</span>
            </Link>

            <Link href="#" className="flex flex-col items-center px-1 py-1">
              <div className="flex items-center justify-center h-9 w-9 rounded-md text-gray-500">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
                </svg>
              </div>
              <span className="text-xs mt-0.5 text-gray-500">Messaging</span>
            </Link>

            <Link href="#" className="flex flex-col items-center px-1 py-1">
              <div className="flex items-center justify-center h-9 w-9 rounded-md text-gray-500">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
                  <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" />
                </svg>
              </div>
              <span className="text-xs mt-0.5 text-gray-500">Notifications</span>
            </Link>

            <Link href="/profile" className="flex flex-col items-center">
              <div className="h-7 w-7 rounded-full overflow-hidden">
                <img src="/placeholder.svg?height=32&width=32" alt="User" className="h-full w-full object-cover" />
              </div>
              <span className="text-xs mt-0.5">Me ▼</span>
            </Link>
          </nav>
        </div>
      </header>

      <main className="container px-4 py-6 mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {/* Left Sidebar */}
          <div className="md:col-span-1">
            <div className="bg-white rounded-lg shadow">
              <div className="p-4">
                <h3 className="text-base font-medium mb-2">Manage my network</h3>
              </div>
              <div className="p-0">
                <nav className="space-y-1">
                  {[
                    { label: "Connections", count: 467 },
                    { label: "Contacts", count: 1243 },
                    { label: "Following & Followers", count: 82 },
                    { label: "Groups", count: 5 },
                    { label: "Events", count: 0 },
                    { label: "Pages", count: 12 },
                    { label: "Newsletter", count: 3 },
                    { label: "Hashtags", count: 8 },
                  ].map((item, i) => (
                    <Link key={i} href="#" className="flex items-center justify-between px-4 py-2 hover:bg-gray-100">
                      <span className="text-sm">{item.label}</span>
                      <span className="text-sm text-gray-500">{item.count}</span>
                    </Link>
                  ))}
                </nav>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="md:col-span-3 space-y-6">
            {/* Invitations */}
            <div className="bg-white rounded-lg shadow">
              <div className="flex flex-row items-center justify-between p-4">
                <h3 className="text-base font-medium">Invitations</h3>
                <Link href="#" className="text-sm text-blue-600 font-medium">
                  See all 8
                </Link>
              </div>
              <div className="p-4 pt-0 space-y-4">
                <div className="flex items-start justify-between">
                  <div className="flex gap-3">
                    <div className="h-14 w-14 rounded-full overflow-hidden">
                      <img
                        src="/placeholder.svg?height=56&width=56"
                        alt="Emily Chen"
                        className="h-full w-full object-cover"
                      />
                    </div>
                    <div>
                      <h4 className="font-medium">Emily Chen</h4>
                      <p className="text-sm text-gray-500">Product Designer at Design Studio</p>
                      <p className="text-sm text-gray-500">
                        <span className="inline-flex items-center mr-2">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="12"
                            height="12"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            className="h-3 w-3 mr-1"
                          >
                            <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                            <circle cx="9" cy="7" r="4" />
                            <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                            <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                          </svg>
                          12 mutual connections
                        </span>
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button className="px-3 py-1 border border-gray-300 rounded text-sm hover:bg-gray-50">
                      Ignore
                    </button>
                    <button className="px-3 py-1 bg-blue-600 text-white rounded text-sm hover:bg-blue-700">
                      Accept
                    </button>
                  </div>
                </div>

                <div className="flex items-start justify-between">
                  <div className="flex gap-3">
                    <div className="h-14 w-14 rounded-full overflow-hidden">
                      <img
                        src="/placeholder.svg?height=56&width=56"
                        alt="David Kim"
                        className="h-full w-full object-cover"
                      />
                    </div>
                    <div>
                      <h4 className="font-medium">David Kim</h4>
                      <p className="text-sm text-gray-500">Software Engineer at Tech Solutions</p>
                      <p className="text-sm text-gray-500">
                        <span className="inline-flex items-center mr-2">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="12"
                            height="12"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            className="h-3 w-3 mr-1"
                          >
                            <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                            <circle cx="9" cy="7" r="4" />
                            <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                            <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                          </svg>
                          8 mutual connections
                        </span>
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button className="px-3 py-1 border border-gray-300 rounded text-sm hover:bg-gray-50">
                      Ignore
                    </button>
                    <button className="px-3 py-1 bg-blue-600 text-white rounded text-sm hover:bg-blue-700">
                      Accept
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* People You May Know */}
            <div className="bg-white rounded-lg shadow">
              <div className="p-4">
                <h3 className="text-base font-medium mb-4">People you may know</h3>
              </div>
              <div className="p-4 pt-0">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {[
                    { name: "Sarah Johnson", title: "UX Designer at Creative Co", mutual: 15 },
                    { name: "Michael Lee", title: "Frontend Developer at Web Solutions", mutual: 7 },
                    { name: "Jessica Wang", title: "Product Manager at Tech Innovations", mutual: 23 },
                    { name: "Robert Chen", title: "Data Scientist at Analytics Inc", mutual: 5 },
                    { name: "Amanda Taylor", title: "Marketing Specialist at Brand Agency", mutual: 12 },
                    { name: "Daniel Park", title: "Software Architect at Cloud Systems", mutual: 9 },
                  ].map((person, i) => (
                    <div key={i} className="border rounded-lg bg-white">
                      <div className="p-4">
                        <div className="flex flex-col items-center text-center">
                          <div className="h-20 w-20 rounded-full overflow-hidden mb-3">
                            <img
                              src={`/placeholder.svg?height=80&width=80&text=${person.name.charAt(0)}`}
                              alt={person.name}
                              className="h-full w-full object-cover"
                            />
                          </div>
                          <h4 className="font-medium">{person.name}</h4>
                          <p className="text-sm text-gray-500 mb-2">{person.title}</p>
                          <p className="text-xs text-gray-500 mb-3">
                            <span className="inline-flex items-center">
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="12"
                                height="12"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="h-3 w-3 mr-1"
                              >
                                <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                                <circle cx="9" cy="7" r="4" />
                                <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                                <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                              </svg>
                              {person.mutual} mutual connections
                            </span>
                          </p>
                          <button className="w-full border border-gray-300 rounded py-1 px-3 hover:bg-gray-50">
                            Connect
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <button className="w-full border border-gray-300 rounded py-2 px-3 mt-4 hover:bg-gray-50">
                  Show more
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

